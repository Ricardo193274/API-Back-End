package br.upf.sistemaaplicacoes

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class SistemaaplicacoesApplicationTests {

	@Test
	fun contextLoads() {
	}

}
