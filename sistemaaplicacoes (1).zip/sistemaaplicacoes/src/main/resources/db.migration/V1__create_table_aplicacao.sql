CREATE TABLE `aplicacao` (
`id` bigint NOT NULL PRIMARY KEY AUTO_INCREMENT,
`data` DATE NOT NULL,
`descricao` varchar(255) DEFAULT NULL,
`nome` varchar(255) NOT NULL,
`status` enum('ON','OFF') DEFAULT NULL
);
