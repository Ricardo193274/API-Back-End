package br.upf.sistemaaplicacoes.dtos

import br.upf.sistemaaplicacoes.model.Inscricao
import br.upf.sistemaaplicacoes.model.StatusAplicacao
import jakarta.validation.constraints.NotBlank
import jakarta.validation.constraints.NotNull
import java.time.LocalDate

data class AplicacaoDTO(
    @field:NotBlank(message = "Aplicativo sempre deve ter um nome!")
    val nome: String,
    @field:NotNull(message = "Aplicativo deve ter um estado (on ou off)")
    val data: LocalDate,
    @field:NotBlank(message = "Aplicativo deve ter uma descrição")
    val descricao: String,
    val status: StatusAplicacao
)
