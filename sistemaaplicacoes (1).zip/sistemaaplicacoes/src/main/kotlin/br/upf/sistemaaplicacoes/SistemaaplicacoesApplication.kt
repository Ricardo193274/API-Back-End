package br.upf.sistemaaplicacoes

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class SistemaaplicacoesApplication

fun main(args: Array<String>) {
	runApplication<SistemaaplicacoesApplication>(*args)
}
