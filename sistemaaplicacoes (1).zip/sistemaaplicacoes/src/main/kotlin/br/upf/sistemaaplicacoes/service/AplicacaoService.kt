package br.upf.sistemaaplicacoes.service

import br.upf.sistemaaplicacoes.converters.AplicacaoConverter
import br.upf.sistemaaplicacoes.dtos.AplicacaoDTO
import br.upf.sistemaaplicacoes.dtos.AplicacaoResponseDTO
import br.upf.sistemaaplicacoes.repository.AplicacaoRepository
import br.upf.sistemaaplicacoes.exceptions.NotFoundException
import org.springframework.data.domain.Page
import org.springframework.data.domain.Pageable
import org.springframework.stereotype.Service

private const val ERROR_MESSAGE = "Aplicação não encontrado!!!"

@Service
class AplicacaoService(private val repository: AplicacaoRepository, val converter: AplicacaoConverter) {

    fun listar(
        nomeAplicacao: String?,
        paginacao: Pageable
    ): Page<AplicacaoResponseDTO> {
        val aplicacoes = if (nomeAplicacao == null) {
            repository.findAll(paginacao)
        } else {
            repository.findByNome(nomeAplicacao, paginacao)
        }

        return aplicacoes.map(converter::toAplicacaoResponseDTO)
    }

    fun buscarPorId(id: Long): AplicacaoResponseDTO {
        val aplicacao = repository.findById(id)
            .orElseThrow{ NotFoundException(ERROR_MESSAGE) }
        return converter.toAplicacaoResponseDTO(aplicacao)
    }

    fun cadastrar(dto: AplicacaoDTO): AplicacaoResponseDTO {
        return converter.toAplicacaoResponseDTO(
            repository.save(converter.toAplicacao(dto))
        )
    }

    fun atualizar(id: Long, dto: AplicacaoDTO) : AplicacaoResponseDTO {
        val aplicacao = repository.findById(id)
            .orElseThrow{ NotFoundException(ERROR_MESSAGE) }
            .copy(nome = dto.nome,
                //data = dto.data,
                descricao = dto.descricao,
                status = dto.status
            )
        return converter.toAplicacaoResponseDTO(
            repository.save(aplicacao)
        )
    }

    fun deletar(id: Long) {
        repository.deleteById(id)
    }
}
