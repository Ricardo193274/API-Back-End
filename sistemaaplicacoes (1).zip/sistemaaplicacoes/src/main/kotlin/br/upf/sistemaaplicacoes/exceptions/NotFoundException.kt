package br.upf.sistemaaplicacoes.exceptions

class NotFoundException(override val message: String) : RuntimeException() {
}