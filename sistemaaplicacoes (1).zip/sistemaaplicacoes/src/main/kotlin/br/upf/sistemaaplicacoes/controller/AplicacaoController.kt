package br.upf.sistemaaplicacoes.controller

import br.upf.sistemaaplicacoes.dtos.AplicacaoDTO
import br.upf.sistemaaplicacoes.dtos.AplicacaoResponseDTO
import br.upf.sistemaaplicacoes.service.AplicacaoService
import jakarta.transaction.Transactional
import jakarta.validation.Valid
import org.springframework.data.domain.Page
import org.springframework.data.domain.Pageable
import org.springframework.data.web.PageableDefault
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.ResponseStatus
import org.springframework.web.bind.annotation.RestController
import org.springframework.web.util.UriComponentsBuilder

@RestController
@RequestMapping("/aplicacoes")
class AplicacaoController(val service: AplicacaoService) {

    @GetMapping
    fun listar(@RequestParam(required = false) nomeAplicacao: String?, @PageableDefault(size = 10) paginacao: Pageable): Page<AplicacaoResponseDTO> {
        return service.listar(nomeAplicacao, paginacao)
    }

    @GetMapping("/{id}")
    fun buscarPorId(@PathVariable id: Long): AplicacaoResponseDTO {
        return service.buscarPorId(id)
    }

    @PostMapping
    @Transactional
    fun cadastrar(@RequestBody @Valid aplicacao: AplicacaoDTO, uriBuilder: UriComponentsBuilder): ResponseEntity<AplicacaoResponseDTO> {
        val aplicacaoResponse = service.cadastrar(aplicacao)
        val uri = uriBuilder.path("/aplicacoes/${aplicacaoResponse.id}").build().toUri()
        return ResponseEntity.created(uri).body(aplicacaoResponse)
    }

    @PutMapping("/{id}")
    @Transactional
    fun atualizar(@PathVariable id: Long, @RequestBody @Valid aplicacao: AplicacaoDTO): AplicacaoResponseDTO {
        return service.atualizar(id, aplicacao)
    }

    @DeleteMapping("/{id}")
    @Transactional
    @ResponseStatus(HttpStatus.NO_CONTENT)
    fun deletar(@PathVariable id: Long) {
        service.deletar(id)
    }
}
