package br.upf.sistemaaplicacoes.converters

import br.upf.sistemaaplicacoes.dtos.AplicacaoDTO
import br.upf.sistemaaplicacoes.dtos.AplicacaoResponseDTO
import br.upf.sistemaaplicacoes.model.Aplicacao
import org.springframework.stereotype.Component

@Component
class AplicacaoConverter {

    fun toAplicacao(dto: AplicacaoDTO) : Aplicacao {
        return Aplicacao(
            nome = dto.nome,
            descricao = dto.descricao,
            status = dto.status,
        )
    }

    fun toAplicacaoResponseDTO(aplicacao: Aplicacao): AplicacaoResponseDTO {
        return AplicacaoResponseDTO(
            id = aplicacao.id!!,
            nome = aplicacao.nome,
            status = aplicacao.status,
            descricao = aplicacao.descricao,
        )
    }

}