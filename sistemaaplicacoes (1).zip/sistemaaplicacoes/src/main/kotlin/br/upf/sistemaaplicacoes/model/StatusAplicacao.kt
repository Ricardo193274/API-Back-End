package br.upf.sistemaaplicacoes.model

enum class StatusAplicacao{
    PREVISTO,
    ABERTO,
    ENCERRADO,
    CANCELADO
}
