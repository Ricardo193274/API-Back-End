package br.upf.sistemaaplicacoes.model

import jakarta.persistence.*

@Entity
data class Aplicacao(
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    val id: Long? = null,
    val nome: String,
    val descricao: String,
    @Enumerated(value = EnumType.STRING)
    val status: StatusAplicacao

)
