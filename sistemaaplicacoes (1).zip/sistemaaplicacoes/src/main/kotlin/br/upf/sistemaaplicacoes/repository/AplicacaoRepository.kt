package br.upf.sistemaaplicacoes.repository

import br.upf.sistemaaplicacoes.model.Aplicacao
import org.springframework.data.domain.Page
import org.springframework.data.domain.Pageable
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository

@Repository
interface AplicacaoRepository: JpaRepository<Aplicacao, Long> {
    fun findByNome(nomeAplicacao: String, paginacao: Pageable): Page<Aplicacao>

}