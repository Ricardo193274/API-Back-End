package br.upf.sistemaaplicacoes.dtos

import br.upf.sistemaaplicacoes.model.StatusAplicacao

data class AplicacaoResponseDTO(
    val id: Long,
    val nome: String,
    val descricao: String,
    val status: StatusAplicacao
)